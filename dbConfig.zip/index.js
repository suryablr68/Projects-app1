'use strict';

// declare variables
var mysql = require('mysql');
var dbconfig = require('./dbConfig.json');

var pool = mysql.createPool({
    host: dbconfig.dbhost,
    user: dbconfig.dbuser,
    password: dbconfig.dbpassword,
    database: dbconfig.dbname
});


exports.handler = (event, context, callback) => {

    context.callbackWaitsForEmptyEventLoop = false;

    // get db connection
    pool.getConnection(function (err, connection) {

        // Check Connection
        if (err) {
            console.log("Not Connected.!!");
            callback(err);
        } else {
            console.log("Connected to DB : " + dbconfig.dbname);
        }

        // extract api input 
        var inputJSON = JSON.stringify(event);


        connection.query('CALL `schema`.`procedure`( ?, @p_out)', [inputJSON],
            function (error, results, fields) {

                // And done with the connection.
                connection.release();

                if (error) {

                    callback(error);
                } else {

                    callback(null, results[0]);

                    console.log(
                        JSON.parse(JSON.stringify({
                            "status": 200,
                            "error": null,
                            "response": results[0]
                        }))

                    );
                    //If there is no error, all is good and response is 200OK.
                }


            });


    });

};