'use strict';

// declare variables
var mysql = require('mysql');
var dbconfig = require('./dbConfig.json');

var pool = mysql.createPool({
    host: dbconfig.dbhost,
    user: dbconfig.dbuser,
    password: dbconfig.dbpassword,
    database: dbconfig.dbname
});

var input = {
	user_name : "demo_user1",
	user_password : "welcome*123"
};

var inputJSON = JSON.stringify(input);


pool.getConnection(function (err, connection) {

    // Use the connection
    

    connection.query('CALL `devdbInstance1`.`validateUser`( ?, @p_out)', [inputJSON],
  
      function (error, results, fields) {

        
        // And done with the connection.
        connection.release();
        // Handle error after the release.
        if (error) {
            console.log("Here");
            console.log(error);
        }
        else
  
          console.log(
            JSON.parse(JSON.stringify({
              "status": 200,
              "error": null,
              "response": results[0]
            }))
  
          );
  
        process.exit();
      }
  
    );
  
  });